// main.js
const mysql = require('mysql');
const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'your_password'  // Replace with your MySQL password
});

connection.connect(err => {
  if (err) throw err;
  console.log("Connected to MySQL!");

  connection.query("CREATE DATABASE IF NOT EXISTS college", err => {
    if (err) throw err;

    
    connection.changeUser({ database: 'college' }, err => {
      if (err) throw err;

      const tableQuery = `
        CREATE TABLE IF NOT EXISTS students (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255),
          age INT
        )
      `;
      connection.query(tableQuery, err => {
        if (err) throw err;
        console.log("Table 'students' created!");

        // Sample data to insert
        const students = [
          ['Alice', 20],
          ['Bob', 22],
          ['Charlie', 19]
        ];

        // Insert sample data (batch insertion)
        connection.query("INSERT INTO students (name, age) VALUES ?", [students], err => {
          if (err) throw err;
          console.log("Sample data inserted!");
          connection.end();
        });
      });
    });
  });
});