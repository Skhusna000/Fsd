exports.getCurrentDateTime = function() {
    return new Date().toString();
  };
  