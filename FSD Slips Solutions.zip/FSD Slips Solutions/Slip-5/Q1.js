const http = require('http');

http.createServer((req, res) => {
  if (req.url === '/' && req.method === 'GET') {
    // Serve HTML form with an upload field
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>File Upload</title>
      </head>
      <body>
        <h1>Upload File</h1>
        <form action="/upload" method="post" enctype="multipart/form-data">
          <input type="file" name="myfile"><br><br>
          <button type="submit">Upload</button>
        </form>
      </body>
      </html>
    `);
  } else if (req.url === '/upload' && req.method === 'POST') {
    // A minimal response for file uploads (processing not implemented)
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('File upload received. (Upload processing not implemented in this simple example.)');
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
}).listen(3000, () => console.log('Server running at http://localhost:3000'));