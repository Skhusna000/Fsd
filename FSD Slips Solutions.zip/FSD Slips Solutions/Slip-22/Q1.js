const express = require('express');
const app = express();
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.send(`
    <h2>Employee Registration</h2>
    <form method="POST" action="/register">
      <input type="text" name="name" placeholder="Name"><br>
      <input type="text" name="email" placeholder="Email"><br>
      <input type="text" name="mobile" placeholder="Mobile"><br>
      <input type="text" name="department" placeholder="Department"><br>
      <input type="date" name="joiningDate"><br>
      <button type="submit">Register</button>
    </form>
  `);
});

app.post('/register', (req, res) => {
  const { name, email, mobile, department, joiningDate } = req.body;
  if (!name || !/^[A-Za-z\s]+$/.test(name)) return res.send("Invalid name.");
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.send("Invalid email.");
  if (!mobile || !/^\d{10}$/.test(mobile)) return res.send("Invalid mobile number.");
  if (!department) return res.send("Department required.");
  if (!joiningDate) return res.send("Joining date required.");
  res.send("Employee registered successfully!");
});

app.listen(3000, () => console.log("Server running at http://localhost:3000"));
