const EventEmitter = require('events');
const emitter = new EventEmitter();

emitter.on('eventDetected', (data) => {
  console.log('Event detected:', data);
});

// Main loop simulation: Print a message indicating we're waiting for events
console.log('Listening for events...');

// Simulate an event occurring after 2 seconds
setTimeout(() => {
  emitter.emit('eventDetected', 'Hello, event-driven world!');
}, 2000);