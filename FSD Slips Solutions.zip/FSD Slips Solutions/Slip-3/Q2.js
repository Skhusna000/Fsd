const { MongoClient } = require('mongodb');

const url = 'mongodb://localhost:27017/';
const dbName = 'school';

async function main() {
  const client = new MongoClient(url, { useUnifiedTopology: true });
  try {
    await client.connect();
    const db = client.db(dbName);
    const teachers = db.collection('Teacher');

    // Insert sample teacher data
    await teachers.insertMany([
      { name: "Alice", salary: 25000 },
      { name: "Bob", salary: 18000 },
      { name: "Charlie", salary: 30000 },
      { name: "David", salary: 15000 }
    ]);

    // Find teachers with salary greater than 20,000
    const result = await teachers.find({ salary: { $gt: 20000 } }).toArray();
    console.log("Teachers with salary > 20,000:");
    console.log(result);
  } catch (err) {
    console.error(err);
  } finally {
    await client.close();
  }
}

main();