// login.js
const http = require('http');
const qs = require('querystring');

const users = { skhusna: '54321', husna: '12345' };

http.createServer((req, res) => {
  if (req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`
      <form method="POST">
        Username: <input name="username"><br>
        Password: <input name="password" type="password"><br>
        <button type="submit">Login</button>
      </form>
    `);
  } else if (req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const { username, password } = qs.parse(body);
      res.writeHead(200, { 'Content-Type': 'text/html' });
      if (users[username] === password) {
        res.end('Login successful!');
      } else {
        res.end('Login failed!');
      }
    });
  }
}).listen(3000, () => console.log('Server running on http://localhost:3000'));
