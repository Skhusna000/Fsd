const mysql = require('mysql');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'your_password' // Replace with your MySQL password
});

db.connect(err => {
  if (err) throw err;
  db.query("CREATE DATABASE IF NOT EXISTS movieDB", err => {
    if (err) throw err;
    db.changeUser({ database: 'movieDB' }, err => {
      if (err) throw err;
      db.query(`CREATE TABLE IF NOT EXISTS movies (
                  id INT AUTO_INCREMENT PRIMARY KEY,
                  title VARCHAR(255),
                  release_year INT
                )`, err => {
        if (err) throw err;
        const movies = [
          ['The Matrix', 1999],
          ['Inception', 2010],
          ['Interstellar', 2014]
        ];
        db.query("INSERT INTO movies (title, release_year) VALUES ?", [movies], err => {
          if (err) throw err;
          console.log("Database, table, and sample data created!");
          db.end();
        });
      });
    });
  });
});