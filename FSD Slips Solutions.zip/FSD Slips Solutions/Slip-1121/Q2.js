// app.js
const express = require('express');
const app = express();
const PORT = 3000;

app.get('/', (req, res) => {
  // The second parameter sets the filename the browser will see
  res.download(__dirname + '/sample.txt', 'download-sample.txt', err => {
    if (err) {
      console.error("Error sending file:", err);
      res.status(500).send("Error occurred while downloading the file.");
    }
  });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});