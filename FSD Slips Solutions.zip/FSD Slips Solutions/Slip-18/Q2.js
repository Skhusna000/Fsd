const { MongoClient } = require('mongodb');
const url = 'mongodb://localhost:27017';
const dbName = 'your_database'; // Replace with your MongoDB database name

MongoClient.connect(url, (err, client) => {
  if (err) throw err;
  console.log("Connected to MongoDB.");
  const db = client.db(dbName);
  const customers = db.collection('customers');

  // Insert sample customer documents
  customers.insertMany([
    { name: 'Alice', email: 'alice@example.com' },
    { name: 'Bob', email: 'bob@example.com' },
    { name: 'Andrew', email: 'andrew@example.com' },
    { name: 'Charlie', email: 'charlie@example.com' }
  ], (err, result) => {
    if (err) throw err;
    console.log("Inserted", result.insertedCount, "records.");

    // Find customers whose name starts with 'A'
    customers.find({ name: { $regex: /^A/ } }).toArray((err, docs) => {
      if (err) throw err;
      console.log("Customers with name starting with 'A':", docs);
      client.close();
    });
  });
});