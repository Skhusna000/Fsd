const http = require('http');
const qs = require('querystring');

http.createServer((req, res) => {
  if (req.method === 'GET') {
    res.end(`
      <html>
        <body>
          <form method="POST">
            <input name="str1" placeholder="String 1"><br>
            <input name="str2" placeholder="String 2"><br>
            <button type="submit">Concatenate</button>
          </form>
        </body>
      </html>
    `);
  } else if (req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const data = qs.parse(body);
      const result = (data.str1 || '') + (data.str2 || '');
      res.end(`<h1>Result: ${result}</h1>`);
    });
  }
}).listen(3000, () => console.log('Server running at http://localhost:3000'));