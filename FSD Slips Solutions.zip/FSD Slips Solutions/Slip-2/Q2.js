const http = require('http');
const fs = require('fs');
const qs = require('querystring');

http.createServer((req, res) => {
  if (req.method === 'GET') {
    res.writeHead(200, {'Content-Type': 'text/html'});
    res.end(`
      <form method="POST">
        Source File: <input name="src"><br>
        Destination File: <input name="dest"><br>
        <button type="submit">Append</button>
      </form>
    `);
  } else if (req.method === 'POST') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const { src, dest } = qs.parse(body);
      fs.readFile(src, 'utf8', (err, data) => {
        if (err) return res.end('Error reading source file.');
        fs.appendFile(dest, data, err => {
          if (err) return res.end('Error appending to destination file.');
          res.end('Content appended successfully!');
        });
      });
    });
  }
}).listen(3000, () => console.log('Server running on http://localhost:3000'));