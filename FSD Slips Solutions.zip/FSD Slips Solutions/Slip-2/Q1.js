const input = "Full Stack!";
const reversed = input.split("").reverse().join("");
console.log(reversed);