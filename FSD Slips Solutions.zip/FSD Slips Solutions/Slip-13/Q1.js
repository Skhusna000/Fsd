const str = "HELLO WORLD!";
console.log(str.toLowerCase());
