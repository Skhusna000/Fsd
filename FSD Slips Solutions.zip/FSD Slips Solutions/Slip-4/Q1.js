const express = require('express');
const app = express();
const port = 3000;

const courses = [
  { id: 1, title: "Node.js Basics", description: "Learn the basics of Node.js", lessons: ["Intro", "Setup", "Hello World"] },
  { id: 2, title: "JavaScript Fundamentals", description: "Fundamentals of JavaScript", lessons: ["Variables", "Functions", "Loops"] }
];

// Home route: list all courses
app.get('/', (req, res) => {
  let html = '<h1>eLearning System</h1><ul>';
  courses.forEach(course => {
    html += `<li><a href="/course/${course.id}">${course.title}</a></li>`;
  });
  html += '</ul>';
  res.send(html);
});

// Course details route
app.get('/course/:id', (req, res) => {
  const course = courses.find(c => c.id == req.params.id);
  if (!course) return res.send('<h1>Course not found</h1><a href="/">Back</a>');
  let html = `<h1>${course.title}</h1>
              <p>${course.description}</p>
              <h2>Lessons:</h2>
              <ul>`;
  course.lessons.forEach(lesson => { html += `<li>${lesson}</li>`; });
  html += `</ul><a href="/">Back to Courses</a>`;
  res.send(html);
});

app.listen(port, () => console.log(`Server is running on http://localhost:${port}`));