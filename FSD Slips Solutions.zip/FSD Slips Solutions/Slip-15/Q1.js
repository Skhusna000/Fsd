const { MongoClient } = require('mongodb');
const url = 'mongodb://localhost:27017';
const dbName = 'your_database'; // Replace with your database name

MongoClient.connect(url, (err, client) => {
  if (err) throw err;
  console.log("Connected to MongoDB.");
  
  const db = client.db(dbName);
  const students = db.collection('students');

  students.insertMany([
    { name: 'Alice', age: 20 },
    { name: 'Bob', age: 22 },
    { name: 'Charlie', age: 19 }
  ], (err, result) => {
    if (err) throw err;
    console.log("Inserted records:", result.insertedCount);

    students.find({}).toArray((err, docs) => {
      if (err) throw err;
      console.log("Student records:", docs);
      client.close();
    });
  });
});