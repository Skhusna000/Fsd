const { MongoClient } = require('mongodb');
const url = 'mongodb://localhost:27017';
const dbName = 'testDB'; // Replace with your actual database name

MongoClient.connect(url, (err, client) => {
  if (err) {
    console.error('Error connecting to MongoDB:', err);
    return;
  }
  console.log('Connected to MongoDB.');
  
  const db = client.db(dbName);
  const customers = db.collection('customers');

  customers.insertMany([
    { name: 'Alice', email: 'alice@example.com', age: 25 },
    { name: 'Bob', email: 'bob@example.com', age: 30 },
    { name: 'Charlie', email: 'charlie@example.com', age: 35 }
  ], (err, insertResult) => {
    if (err) {
      console.error('Error inserting records:', err);
      client.close();
      return;
    }
    console.log('Inserted records count:', insertResult.insertedCount);

    // Select all records from "customers" collection
    customers.find({}).toArray((err, results) => {
      if (err) {
        console.error('Error fetching records:', err);
      } else {
        console.log('Customer Records:', results);
      }
      client.close();
    });
  });
});