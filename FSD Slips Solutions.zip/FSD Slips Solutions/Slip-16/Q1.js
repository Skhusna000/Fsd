const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

// Array of recipes with id, name, and PDF filename.
const recipes = [
  { id: 1, name: "Spaghetti Bolognese", pdf: "recipe1.pdf" },
  { id: 2, name: "Chicken Curry", pdf: "recipe2.pdf" },
  { id: 3, name: "Vegetable Stir Fry", pdf: "recipe3.pdf" }
];

// Home page: List recipes with a button for each.
app.get('/', (req, res) => {
  let output = '<h1>Recipe Book</h1><ul>';
  recipes.forEach(recipe => {
    output += `<li>
      ${recipe.name} 
      <a href="/download/${recipe.id}"><button>View PDF</button></a>
    </li>`;
  });
  output += '</ul>';
  res.send(output);
});

// Download route: Serve the PDF file for the selected recipe.
app.get('/download/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const recipe = recipes.find(r => r.id === id);
  if (!recipe) return res.status(404).send('Recipe not found');
  
  const filePath = path.join(__dirname, 'pdf', recipe.pdf);
  res.download(filePath, recipe.pdf, err => {
    if (err) {
      console.error("Error sending file:", err);
      res.status(500).send("Error downloading file");
    }
  });
});

app.listen(port, () => {
  console.log(`Recipe Book app is running at http://localhost:${port}`);
});