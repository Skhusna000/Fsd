// main.js
const mysql = require('mysql');

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'your_password'  // Replace with your MySQL password
});

connection.connect(err => {
  if (err) throw err;
  console.log("Connected to MySQL!");

  connection.query("CREATE DATABASE IF NOT EXISTS studentDB", err => {
    if (err) throw err;
    console.log("Database 'studentDB' is ready.");

    connection.changeUser({ database: 'studentDB' }, err => {
      if (err) throw err;

      const createTableQuery = `
        CREATE TABLE IF NOT EXISTS students (
          id INT AUTO_INCREMENT PRIMARY KEY,
          name VARCHAR(255),
          age INT,
          email VARCHAR(255)
        )
      `;
      connection.query(createTableQuery, err => {
        if (err) throw err;
        console.log("Table 'students' created successfully!");
        connection.end();
      });
    });
  });
});